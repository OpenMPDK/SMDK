## IMDB demo application

This application demonstrates possible usage of PNM IMDB library. It performs InRange operation in sequential and multithreaded way with different output types (bit vectors or index vectors).

To run app use next command: `./imdb_demo <tables_root>`, where `tables_root` is a directory where tables, ranges and golden vectors will be generated.
