Please use braces for bodies of all `if` and loops (`for`, `do while` and `while`)
statements even statement is single.

Ex:
```
if (condition) {
  statement;
}
```
