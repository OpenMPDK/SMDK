TODO comments must have the following style:
```
// [TODO: @assignee AXDIMM-123] description goes here
```
(meta information inside brackets is optional).
